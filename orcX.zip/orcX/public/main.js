angular.module('app', [
    'ui.router'
]);

angular.module('app').config(ConfigMain);

ConfigMain.$inject = ['$stateProvider'];

function ConfigMain ($stateProvider) {
    $stateProvider
        .state({
            name: 'leadList',
            url: '/leads',
            templateUrl: '/partials/leads/list.html',
            controller: 'LeadListController',
            controllerAs: 'vm'
        })
        .state({
            name: 'leadNovo',
            url: '/leads/novo',
            templateUrl: '/partials/leads/form.html',
            controller: 'LeadFormController',
            controllerAs: 'vm'
        })
        .state({
            name: 'leadEditar',
            url: '/leads/:id',
            templateUrl: '/partials/leads/form.html',
            controller: 'LeadFormController',
            controllerAs: 'vm'
        })
        .state({
            name: 'prodservList',
            url: '/prodserv',
            templateUrl: '/partials/prodserv/list.html',
            controller: 'ProdServListController',
            controllerAs: 'vm'
        })
        .state({
            name: 'prodservNovo',
            url: '/prodserv/novo',
            templateUrl: '/partials/prodserv/form.html',
            controller: 'ProdServFormController',
            controllerAs: 'vm'
        })
        .state({
            name: 'prodservEditar',
            url: '/prodserv/:id',
            templateUrl: '/partials/prodserv/form.html',
            controller: 'ProdServFormController',
            controllerAs: 'vm'
        })
        .state({
            name: 'orcamentoList',
            url: '/orcamentos',
            templateUrl: '/partials/orcamentos/list.html',
            controller: 'OrcamentoListController',
            controllerAs: 'vm'
        })
        .state({
            name: 'orcamentoNovo',
            url: '/orcamentos/novo',
            templateUrl: '/partials/orcamentos/form.html',
            controller: 'OrcamentoFormController',
            controllerAs: 'vm'
        })
        .state({
            name: 'orcamentoEditar',
            url: '/orcamentos/:id',
            templateUrl: '/partials/orcamentos/form.html',
            controller: 'OrcamentoFormController',
            controllerAs: 'vm'
        });
}
