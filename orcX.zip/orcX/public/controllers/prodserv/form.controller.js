angular.module('app')
    .controller('ProdServFormController', ProdServFormController);

ProdServFormController.$inject = [
    'ProdServService', 
    '$stateParams', 
    '$state'
];

function ProdServFormController (ProdServService, $stateParams, $state){
    var vm = this;
    vm.prodserv = {};
    vm.titulo = 'Novo produto/serviço';

    if ($stateParams.id) {
        vm.titulo = 'Editando produto/serviço';
        ProdServService.findOne($stateParams.id)
            .then(function (data) {
                vm.prodserv = data;
            });
    }

    vm.save = function() {
        if ($stateParams.id) {
            ProdServService
                .update($stateParams.id, vm.prodserv)
                .then(function() {
                    $state.go('prodservList');

                });
        } else {
            ProdServService
                .insert(vm.prodserv)
                .then(function() {
                    $state.go('prodservList');
                });
        }
    }
}