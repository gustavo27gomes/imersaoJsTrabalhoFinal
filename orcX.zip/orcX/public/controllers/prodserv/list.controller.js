angular.module('app')
    .controller('ProdServListController', ProdServListController);

ProdServListController.$inject = ['ProdServService'];

function ProdServListController(ProdServService){
    var vm = this;
    vm.prodserv = [];

    function _load() {
        ProdServService.findAll()
            .then(function (dados) {
                vm.prodserv = dados;
            });
    }
    _load();

    vm.excluir = function (id) {
        if (confirm('Deseja realmente excluir o registro?')) {
            ProdServService.remove(id)
                .then(function() {
                    _load();
                });
        }
    }
}