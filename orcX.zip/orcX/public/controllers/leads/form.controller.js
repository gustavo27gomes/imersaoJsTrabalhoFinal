angular.module('app')
    .controller('LeadFormController', LeadFormController);

LeadFormController.$inject = [
    'LeadService', 
    '$stateParams', 
    '$state'
];

function LeadFormController (LeadService, $stateParams, $state){
    var vm = this;
    vm.lead = {};
    vm.titulo = 'Novo lead';

    if ($stateParams.id) {
        vm.titulo = 'Editando lead';
        LeadService.findOne($stateParams.id)
            .then(function (data) {
                vm.lead = data;
            });
    }

    vm.save = function() {
        if ($stateParams.id) {
            LeadService
                .update($stateParams.id, vm.lead)
                .then(function() {
                    $state.go('leadList');
                });
        } else {
            LeadService
                .insert(vm.lead)
                .then(function() {
                    $state.go('leadList');
                });
        }
    }
}