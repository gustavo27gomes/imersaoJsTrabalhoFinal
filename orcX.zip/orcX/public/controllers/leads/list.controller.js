angular.module('app')
    .controller('LeadListController', LeadListController);

LeadListController.$inject = ['LeadService'];

function LeadListController(LeadService){
    var vm = this;
    vm.leads = [];

    function _load() {
        LeadService.findAll()
            .then(function (dados) {
                vm.leads = dados;
            });
    }
    _load();

    vm.excluir = function (id) {
        if (confirm('Deseja realmente excluir o registro?')) {
            LeadService.remove(id)
                .then(function() {
                    _load();
                });
        }
    }
}