angular.module('app')
    .controller('OrcamentoFormController', OrcamentoFormController);

OrcamentoFormController.$inject = [
    'OrcamentoService', 
    'LeadService',
    'ProdServService',
    '$stateParams', 
    '$state'
];

function OrcamentoFormController (OrcamentoService, LeadService, ProdServService, $stateParams, $state){
    var vm = this;
    vm.orcamento = {};
    vm.titulo = 'Novo orcamento';

    vm.leads = [];
    vm.prodserv = [];

    LeadService.findAll()
        .then(function (data) {
            vm.leads = data;
        });
    ProdServService.findAll()
        .then(function (data) {
            vm.prodserv = data;
        });

    if ($stateParams.id) {
        vm.titulo = 'Editando orçamento';
        OrcamentoService.findOne($stateParams.id)
            .then(function (data) {
                vm.orcamento = data;
            });
    }

    vm.save = function() {
        if ($stateParams.id) {
            OrcamentoService
                .update($stateParams.id, vm.orcamento)
                .then(function() {
                    $state.go('orcamentoList');
                });
        } else {
            OrcamentoService
                .insert(vm.orcamento)
                .then(function() {
                    $state.go('orcamentoList');
                });
        }
    }


    vm.addItem = function() {
        vm.orcamento.itens = vm.orcamento.itens || [];
        vm.itemSelecionado = {}
        vm.indexSelecionado = null;
    }

    vm.saveItem = function() {
        if (vm.indexSelecionado) {
            vm.orcamento.itens[vm.indexSelecionado] = vm.itemSelecionado;
        } else {
            vm.orcamento.itens.push(vm.itemSelecionado);
        }
        
    }
}