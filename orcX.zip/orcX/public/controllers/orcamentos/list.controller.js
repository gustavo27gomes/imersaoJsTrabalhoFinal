angular.module('app')
    .controller('OrcamentoListController', OrcamentoListController);

OrcamentoListController.$inject = ['OrcamentoService'];

function OrcamentoListController(OrcamentoService){
    var vm = this;
    vm.orcamentos = [];

    function _load() {
        OrcamentoService.findAll()
            .then(function (dados) {
                vm.orcamentos = dados;
            });
    }
    _load();

    vm.excluir = function (id) {
        if (confirm('Deseja realmente excluir o registro?')) {
            OrcamentoService.remove(id)
                .then(function() {
                    _load();
                });
        }
    }
}