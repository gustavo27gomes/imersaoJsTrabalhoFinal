angular.module('app')
    .service('ProdServService', ProdServService);

ProdServService.$inject = ['$http']

function ProdServService ($http) {
    var URL = '/prodserv';

    var service = this;

    service.findAll = function () {
        return $http.get(URL)
            .then(function(resp) {
                return resp.data;
            });
    }

    service.findOne = function (id) {
        return $http.get(URL + '/' + id)
            .then(function(resp) {
                return resp.data;
            });
    }

    service.update = function (id, prodserv) {
        return $http.put(URL + '/' + id, prodserv)
            .then(function(resp) {
                return resp.data;
            });
    }

    service.remove = function (id) {
        return $http.delete(URL + '/' + id);
    }

    service.insert = function (prodserv) {
        return $http.post(URL, prodserv)
            .then(function(resp) {
                return resp.data;
            });
    }

}