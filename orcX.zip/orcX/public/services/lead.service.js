angular.module('app')
    .service('LeadService', LeadService);

LeadService.$inject = ['$http']

function LeadService ($http) {
    var URL = '/leads';

    var service = this;

    service.findAll = function () {
        return $http.get(URL)
            .then(function(resp) {
                return resp.data;
            });
    }

    service.findOne = function (id) {
        return $http.get(URL + '/' + id)
            .then(function(resp) {
                return resp.data;
            });
    }

    service.update = function (id, lead) {
        return $http.put(URL + '/' + id, lead)
            .then(function(resp) {
                return resp.data;
            });
    }

    service.remove = function (id) {
        return $http.delete(URL + '/' + id);
    }

    service.insert = function (lead) {
        return $http.post(URL, lead)
            .then(function(resp) {
                return resp.data;
            });
    }

}