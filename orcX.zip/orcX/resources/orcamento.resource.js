const mongoose = require('mongoose');
const orcamentoModel = mongoose.model('orcamentos');

module.exports = function (app) {
    app.get('/orcamentos', function (req, resp) {
        orcamentoModel.find({}, ['data', 'lead', 'itens', 'convertido'], {sort: {data: 1}})
            .populate('lead', 'documento nome email')
            .then(
                function (data) {
                    resp.status(200).send(data);
                }, 
                function (err) {
                    resp.status(500).send(err);
                }
            );
    });
    app.post('/orcamentos', function (req, resp) {
        orcamentoModel.create(req.body)
            .then(
                function (data) {
                    resp.status(201).send(data);
                },
                function (err) {
                    resp.status(500).send(err);
                }
            );
    });
    app.get('/orcamentos/:id', function (req, resp) {
        orcamentoModel.findById(req.params.id)
            .populate('lead')
            .populate('itens.prodserv')
            .then(
                function (data) {
                    if (!data) {
                        resp.status(404).send();
                    } else {
                        resp.status(200).send(data);
                    }
                },
                function (err) {
                    resp.status(500).send(err);
                }
            );
    });
    app.put('/orcamentos/:id', function (req, resp) {
        orcamentoModel.findOneAndUpdate({ '_id': req.params.id }, req.body)
            .then(
                function (data) {
                    if (!data) {
                        resp.status(404).send();
                    } else {
                        resp.status(200).send(data);
                    }
                },
                function (err) {
                    resp.status(500).send(err);
                }
            );
    });
    app.delete('/orcamentos/:id', function (req, resp) {
        orcamentoModel.deleteOne({ '_id': req.params.id })
            .then(
                function () {
                    resp.status(204).send();
                },
                function (err) {
                    resp.status(500).send(err);
                }
            );
    });
}